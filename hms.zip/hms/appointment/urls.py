from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = "appointment"

urlpatterns = [
    path("appointments/p/", views.AppointmentsForAPatientView.as_view(), name="patient-appointments"),
    path("appointment/create/", views.CreatePAppointment, name="create-appointment-patient"),

    path("appointments/d/", views.AppointmentsForADoctorView.as_view(), name="doctor-appointments"),
    path("documentation/patient", views.PDocumentationCreateView.as_view(), name="p-documentation"),
    path("documentation/doctor", views.DocumentationCreateView.as_view(), name="doc-documentation"),
    path("documentation/create", views.DocumentationCreate, name="doc-documentation-create"),

    path("appointment/create", views.AppointmentCreateView, name="appointment-create"),
    path("appointment/admin/", views.AppointmentsForAdminView.as_view(), name="admin-appointments"),
    path("appointment/admin/approve/<int:pk>/", views.ApproveAppointments, name="admin-approval"),
    path("rdashboard/", views.rdashboard, name="r_dashboard")
]