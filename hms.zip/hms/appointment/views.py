from django.shortcuts import render, redirect
from .models import * 
from .forms import * 
from user_profile.forms import *
from django.views.generic import ListView, CreateView
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from user_profile.models import UserProfile
from django.contrib import messages
# Create your views here.

@login_required(login_url='/login/')
def PAppointmentCreateView(request):
    data = PatientBooking.objects.all()
    return render(request, 'appointment/patient-appointment.html', {'data': data})

@login_required(login_url='/login/')
def CreatePAppointment(request):
    if request.method == 'POST':
        form = PatientAppointmentForm(request.POST)
        if form.is_valid():
            date = form.cleaned_data['date']
            time = form.cleaned_data['time']
            doctor = form.cleaned_data['doctor'].id
            patient = request.user.id
            appointment = PatientBooking(date=date, doctor_id=doctor, patient_id=patient, time=time)
            appointment.save()
            messages.success(request, 'Appointment Pending Approval by Hospital Admin. Once Approved, we would get back to you. Thank you')
            return redirect('appointment:patient-appointments')
    else:
        form = PatientAppointmentForm()
    return render(request, 'appointment/create-appointment-patient.html', {'form': form})


class AppointmentsForAPatientView(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'account:login'

    def get_queryset(self):
        return PatientBooking.objects.filter(patient=self.request.user)
         


class AppointmentsForADoctorView(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'account:login'

    def get_queryset(self):
        return Appointment.objects.filter(doctor=self.request.user)
    

class DocumentationCreateView(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'account:login'
    def get_queryset(self):
        return Documentation.objects.filter(doctor=self.request.user)

class PDocumentationCreateView(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'account:login'
    def get_queryset(self):
        return Documentation.objects.filter(patient=self.request.user)

@login_required(login_url='/login/')
def DocumentationCreate(request):
    if request.method == 'POST':
        form = DocumentationForm(request.POST)
        if form.is_valid():
            documentation = form.save(commit=False)
            documentation.doctor = request.user
            documentation.save()
            messages.success(request, 'Session successfully Documented!')

            return redirect('appointment:doc-documentation')
    else:
        form = DocumentationForm()
    return render(request, 'appointment/documentation_create.html', {'form': form})


@login_required(login_url='/login/')
def AppointmentCreateView(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.save()
            return redirect('appointment:r_dashboard')
    else:
        form = AppointmentForm()
    return render(request, 'appointment/appointment_create.html', {'form': form})

class AppointmentsForAdminView(LoginRequiredMixin, ListView):
    login_url = '/login/'
    redirect_field_name = 'account:login'

    def get_queryset(self):
        return PatientBooking.objects.all()
    

@login_required(login_url='/login/')
def rdashboard(request):
    if request.method == "GET" and request.user.user_type == "R":
        context = {
            "totalApp" : len(PatientBooking.objects.all()),
            "compApp" : len(PatientBooking.objects.filter(status="Approved")),
            "pendApp" : len(PatientBooking.objects.filter(status="Pending")),
            "totalDoc" : len(User.objects.filter(user_type="D")),
            "totalPat" : len(User.objects.filter(user_type="P"))
        }
        return render(request, 'appointment/r_dashboard.html', context=context)


@login_required(login_url='/login/')
def ApproveAppointments(request, pk):
    patient = User.objects.get(pk=pk)
    profile = PatientBooking.objects.get(patient=patient)
    if request.method == 'POST':
        # Update the specific field
        patient.status = "Approval"
        patient.save()
        # Perform additional operations if necessary
        return render(request, 'appointment/patientbooking_list.html', {'patient': patient})
    
    return render(request, 'appointment/patientbooking_list.html', {})


    