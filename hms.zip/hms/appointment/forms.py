from django import forms
from .models import *
from django.contrib.auth import get_user_model
User = get_user_model()

class DocumentationForm(forms.ModelForm):

    class Meta:
        model = Documentation
        fields = ('patient', 'session_summary')

    def __init__(self, *args, **kwargs):
        super(DocumentationForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['patient'].queryset = User.objects.filter(user_type="P")


class AppointmentForm(forms.ModelForm):

    class Meta:
        model = Appointment
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(AppointmentForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['patient'].queryset = User.objects.filter(user_type="P")
            self.fields['doctor'].queryset = User.objects.filter(user_type="D")
            self.fields["date"].label = "Date (YYYY-MM-DD)"
            self.fields["time"].label = "Time 24 hr (HH:MM)"

class PatientAppointmentForm(forms.ModelForm):
    class Meta:
        model = PatientBooking
        fields = ('date', 'time', 'doctor')

    def __init__(self, *args, **kwargs):
        super(PatientAppointmentForm, self).__init__(*args, **kwargs)
        if self.instance:
            self.fields['doctor'].queryset = User.objects.filter(user_type="D")
            self.fields["date"].label = "Date (YYYY-MM-DD)"
            self.fields["time"].label = "Time 24 hr (HH:MM)"
        
